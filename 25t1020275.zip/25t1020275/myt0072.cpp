#include <bits/stdc++.h>
using namespace std;
int main () {
	long long n; cin >> n;
	long long S = n*n;
	long long div = 1;
	long long temp = n;
	while (temp > 0) {
		div *= 10;
		temp /= 10;
	}
	long long right = S % div;
	long long left = S / div;
	if (left + right == n)
		cout << "YES";
	else
		cout << "NO";
	return 0;
}
