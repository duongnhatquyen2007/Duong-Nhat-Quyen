#include <bits/stdc++.h>
using namespace std;
long long dequy (int m, long long n) {
	if (m == 0) {
		return n + 1;
	}
	else if (n == 0) {
		return dequy(m - 1, 1);
	}
	else {
		long long temp = dequy(m, n - 1);
		return dequy(m - 1, temp);
	}
}
int main() { 
	int m;
	long long n;
	if(!(cin >> m >> n)) {
		return 0;
	}
	long long kq = dequy(m, n);
	cout << kq << endl;
	return 0;
}
