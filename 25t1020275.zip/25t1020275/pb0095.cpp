#include <bits/stdc++.h>
using namespace std;
void solve () {
	int n, k;
	if (!(cin >> n >> k))
		return;
	vector<int> A(n), B(n);
	for (int i=0;i<n;++i)
		cin >> A[i];
	for (int i=0;i<n;++i)
		cin >> B[i];
	k=k%n;
	if (n>0) 
		rotate(A.begin(),A.begin() + (n-k), A.end());
	if (n>0) 
		rotate(B.begin(),B.begin() + k, B.end());
	vector<int> C(n);
	for (int i=0;i<n;++i)
		C[i] = A[i] + B[i];
	for (int i=0;i<n;++i)
		cout << C[i] << (i==n-1 ? "" : " ");
	cout << endl;
}
int main () {
	solve ();
	return 0;
}
