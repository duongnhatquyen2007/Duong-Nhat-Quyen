#include <bits/stdc++.h>
using namespace std;
int main () {
	double x; cin >> x;
	double S;
	if ((x>=0) && (x<3)) {
		S = x*x + sin(x) + 4;
	}
	else if (x>=3) {
		S = exp(x) + 5;
	}
	cout << fixed << setprecision(6) << S;
	return 0;
}
