#include <bits/stdc++.h>
using namespace std;
int demChuSo(long long n) {
    if (n == 0) return 1;
    int count = 0;
    return floor(log10(n)) + 1;
}
bool laSoArmstrong(long long n) {
    if (n < 0) return false;
    long long soGoc = n;
    int k = demChuSo(n);
    long long tongLuyThua = 0; 
    long long temp = soGoc;
    while (temp > 0) {
        int chuSo = temp % 10;
        tongLuyThua += (long long)round(pow(chuSo, k)); 
        if (tongLuyThua > soGoc) return false;

        temp /= 10;
    }
    return tongLuyThua == soGoc;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int N;
    if (!(cin >> N)) return 0;
    int dem = 0;
    for (int i = 0; i < N; ++i) {
        long long a_i;
        if (!(cin >> a_i)) break; 
        
        if (laSoArmstrong(a_i)) {
            dem++;
        }
    }
    cout << dem << endl;
    return 0;
}
