#include <bits/stdc++.h>
using namespace std;
long long daonguoc (long long n) {
	long long sdn=0;
	while (n>0) {
		long long csc=n%10;
		sdn=sdn*10+csc;
		n=n/10;
	}
	return sdn;
}
bool songuyento (long long sdn) {
	if (sdn <= 1) {
		return false;
	}
	for (long long i=2; i*i<=sdn; i++) {
		if (sdn%i==0) {
			return false;
		}
	}
	return true;
}
int main () {
	int T; cin >> T;
	while (T--) {
		long long n_goc; cin >> n_goc;
		long long n_dao_nguoc = daonguoc(n_goc);
		bool la_snt = songuyento(n_dao_nguoc);
		if (la_snt)
			cout << "Yes\n";
		else
			cout << "No\n";
	}
	return 0;
}
